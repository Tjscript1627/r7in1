# R7 Deployment Guide — From Code to Live Game

## What You're Deploying
A complete real-time multiplayer trivia game:
- **20 topics, 293 questions** with difficulty curves and fun facts
- **Real-time 1v1 battles** via WebSockets — two phones playing simultaneously
- **Mobile-first design** — optimized for WhatsApp sharing
- **Server-side timer & scoring** — no cheating possible

---

## Total Time: ~25 minutes | Cost: ₹0

---

## Step 1: Create a GitHub Account (5 min)
*Skip if you already have one*

1. Go to **github.com** → Click **Sign Up**
2. Enter email, create password, pick a username
3. Verify your email

## Step 2: Create a GitHub Repository (3 min)

1. Click the **+** icon (top right) → **New repository**
2. Name it: `r7-game`
3. Set to **Public** (required for free Railway hosting)
4. **Do NOT** check "Add README" — we have our own files
5. Click **Create repository**

## Step 3: Upload the Project Files (5 min)

### Option A: Upload via GitHub.com (Easiest — no coding tools needed)

1. On your new repository page, click **"uploading an existing file"** link
2. Drag and drop these files from the r7-project folder:
   - `server.js`
   - `questions.js`
   - `package.json`
   - `package-lock.json`
   - `Dockerfile`
   - `.gitignore`
   - `public/index.html` ← Create a folder called `public` first (click "Add file" → "Create new file" → type `public/index.html` → paste content)
3. Click **Commit changes**

### Option B: Upload via Git Command Line (If you have Git installed)

```bash
cd r7-project
git init
git add .
git commit -m "R7 v1 — multiplayer trivia game"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/r7-game.git
git push -u origin main
```

## Step 4: Deploy on Railway (10 min)

Railway is a hosting platform that runs your game server for free.

1. Go to **railway.app** → Click **Login** → **Login with GitHub**
2. Authorize Railway to access your GitHub
3. On the dashboard, click **New Project**
4. Select **Deploy from GitHub repo**
5. Find and select **r7-game**
6. Railway will auto-detect the Dockerfile and start building

### Configure the Port
1. Click on your deployed service
2. Go to **Settings** tab
3. Under **Networking**, click **Generate Domain** — this gives you a public URL
4. Under **Variables**, add: `PORT` = `3000` (Railway may set this automatically)

### Wait for Build
- Railway will show build logs
- When you see "⚡ R7 server running on port 3000" — you're live!
- Your game URL will be something like: `r7-game-production.up.railway.app`

## Step 5: Test It! (2 min)

1. Open the Railway URL on your phone
2. Enter your name, pick a topic
3. Copy the invite link → send it to a friend on WhatsApp
4. Friend opens the link → enters their name → joins the room
5. Either player hits "Start Battle" → both phones play simultaneously!

---

## Optional: Custom Domain (15 min extra)

### Buy a Domain
- Go to **namecheap.com** or **domains.google**
- Search for: `playr7.com`, `r7trivia.com`, `r7battle.com`, etc.
- Purchase (~₹800-2000/year)

### Connect to Railway
1. In Railway, go to your service → **Settings** → **Networking**
2. Click **Custom Domain** → enter your domain (e.g., `playr7.com`)
3. Railway will give you DNS records (CNAME or A record)
4. Go to your domain registrar → **DNS Settings**
5. Add the CNAME record Railway provided
6. Wait 5-30 minutes for DNS propagation
7. Your game is now live at `playr7.com`!

---

## How It All Works (Architecture)

```
┌─────────────┐     WhatsApp Link     ┌─────────────┐
│  Player 1   │ ──────────────────────→│  Player 2   │
│  (Phone)    │                        │  (Phone)    │
└──────┬──────┘                        └──────┬──────┘
       │          WebSocket (live)             │
       └──────────────┬───────────────────────┘
                      │
              ┌───────▼───────┐
              │  Railway      │
              │  Game Server  │
              │               │
              │  • Room mgmt  │
              │  • Timer      │
              │  • Scoring    │
              │  • Questions  │
              └───────────────┘
```

- **Player 1** creates a room, shares the link
- **Player 2** opens the link, joins the room
- **Server** sends the same question to both at the exact same time
- **Timer runs server-side** — can't be hacked
- **Answers validated server-side** — no cheating
- When both answer (or time runs out), server sends results to both

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Room not found" when opening link | Room expired (1 hour timeout). Create a new one. |
| Friend can't connect | Check they're on the full URL including `/play/ROOMID` |
| Build fails on Railway | Check that `public/index.html` is in the right folder |
| Game feels laggy | Normal on free tier. Upgrade to paid ($5/mo) for faster response |
| Port issues | Ensure PORT env variable is set to 3000 in Railway |

---

## Scaling Plan

| Stage | Users | Cost | Action Needed |
|-------|-------|------|---------------|
| Friends testing | 1-50 | Free | Nothing |
| Friend group growth | 50-200 | Free | Monitor Railway usage |
| Viral growth | 200-1000 | ~₹1,500/mo | Upgrade Railway plan |
| Serious scale | 1000+ | ~₹5,000/mo | Add Redis, multiple servers |

---

## What's Included

### Server (`server.js`)
- Express HTTP server + Socket.IO WebSocket server
- REST APIs: `/api/topics`, `/api/create-room/:topic`, `/api/room/:roomId`
- Room management: create, join, start, play, rematch
- Game orchestration: question-first reveal, server-side timer, score calculation
- Auto-cleanup: stale rooms deleted after 1 hour
- Graceful disconnect handling

### Question Bank (`questions.js`)
- 20 topics, 293 questions
- Each question: text, 4 options, correct answer, difficulty (1-4), fun fact
- Difficulty curve: 2 easy → 3 medium → 1 hard → 1 true fan per game

### Frontend (`public/index.html`)
- Single-page app with Socket.IO client
- 8 screens: Home, Topics, Waiting Room, Rules, Countdown, Playing, Game Over, Join
- Mobile-first, dark theme, 60fps animations
- Share flow: native share sheet + clipboard fallback
- Fun facts reveal on game-over screen

---

## Next Steps After Deployment

1. **Play 5-10 games with friends** — collect feedback
2. **Expand to 100+ questions per topic** — we can do this together in a focused session
3. **Add more topics** based on friend requests
4. **Custom domain** when you're ready to share widely
5. **Leaderboard** — track wins across games (future feature)
